<?php
  define ( 'HOST', 'localhost' );
  define ( 'PORT', 8081 );
  
  // Create WebSocket.
  $socket = socket_create ( AF_INET, SOCK_STREAM, SOL_TCP );
  socket_set_option ( $websocket, SOL_SOCKET, SO_REUSEADDR, 1 );
  socket_bind ( $websocket, HOST, PORT );
  socket_listen ( $websocket );
  
  $clients = array ( $socket );
  while ( true ) {
    $read = $clients;
    $num_changed_sockets = socket_select ( $read, $write = null, $except = null, 0 );

    if ( $num_changed_sockets === false ) {
      /* Error handling */
      echo "socket_select() failed, reason: " . socket_strerror ( socket_last_error ( ) ) . "\n";
    } else if ( $num_changed_sockets > 0 ) {
      /* At least at one of the sockets something interesting happened */
      // check if there is a client trying to connect
      if ( in_array ( $socket, $read ) ) {
        // accept the client, and add him to the $clients array
        $clients [ ] = $client = socket_accept ( $socket );
        
        // send the client a welcome message
        $header = socket_read ( $client, 1024 );
        $handler->handshake ( $header, $client, HOST, PORT );
        socket_getpeername ( $client, $client_ip );
        $handler->send ( $handler->newConnectionACK ( $client_ip ) );
        
        // remove the listening socket from the clients-with-data array
        $key = array_search ( $socket, $read );
        unset ( $read [ $key ] );
      }
      
      // loop through all the clients that have data to read from
      foreach ( $read as $read_socket ) {
        // read until newline or 1024 bytes
        // socket_read while show errors when the client is disconnected, so silence the error messages
        $data = @socket_read ( $read_socket, 1024, PHP_NORMAL_READ );
        
        // check if the client is disconnected
        if ( $data === false ) {
          // remove client for $clients array
          $key = array_search ( $read_socket, $clients );
          unset ( $clients [ $key ] );
          echo "client disconnected.\n";
          // continue to the next client to read from, if any
          continue;
        }
        
        // trim off the trailing/beginning white spaces
        $data = trim ( $data );
        
        // check if there is any data after trimming off the spaces
        if ( !empty ( $data ) ) {
          // send this to all the clients in the $clients array (except the first one, which is a listening socket)
          foreach ( $clients as $send_socket ) {
            // if its the listening sock or the client that we got the message from, go to the next one in the list
            if ( $send_socket == $socket || $send_socket == $read_socket ) {
              continue;
            }
            // write the message to the client -- add a newline character to the end of the message
            socket_write ( $send_socket, $data . "\n" );
          } // end of broadcast foreach
        }
      } // end of reading foreach
    }
    
    // close the listening socket
    socket_close ( $socket );
  }
  
  /*$client = socket_accept ( $websocket );
  // Send WebSocket handshake headers.
  $request = socket_read($client, 5000);
  preg_match('#Sec-WebSocket-Key: (.*)\r\n#', $request, $matches);
  $key = base64_encode(pack(
      'H*',
      sha1($matches[1] . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
  ));
  $headers = "HTTP/1.1 101 Switching Protocols\r\n";
  $headers .= "Upgrade: websocket\r\n";
  $headers .= "Connection: Upgrade\r\n";
  $headers .= "Sec-WebSocket-Version: 13\r\n";
  $headers .= "Sec-WebSocket-Accept: $key\r\n\r\n";
  socket_write($client, $headers, strlen($headers));
  // Send messages into WebSocket in a loop.
  while (true) {
      sleep(1);
      $content = 'Now: ' . time();
      $response = chr(129) . chr(strlen($content)) . $content;
      socket_write($client, $response);
  }*/
?>