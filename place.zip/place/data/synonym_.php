<?php
  class synonym {
    private $parent = null;
    private $synonyms = [
      "submit" => [
        "button"
      ],
      "button" => [
        "submit",
        "a"
      ],
      "a" => [
        "button"
      ]
    ];
    
    public function __construct ( $parent ) {
      $this->parent = $parent;
      if ( $this->parent->database ) {
        $rows = $this->parent->database->select ( 'links', array ( 'id', 'rate', 'charge', 'word_x', 'word_y' ) );
        if ( sizeof ( $rows ) > 0 ) {
          $synonym = array ( );
          foreach ( $rows as $key => $value ) {
            $rate = $value [ 'rate' ];
            $charge = $value [ 'charge' ];
            $id_x = $value [ 'word_x' ];
            $id_y = $value [ 'word_y' ];
            $rowsWords = $this->parent->database->sql ( "SELECT `word` FROM `words` WHERE `id` = '" . $id_x . "' OR `id` = '" . $id_y . "'" );
            if ( sizeof ( $rowsWords ) == 2 ) {
              $word_x = $rowsWords [ 0 ];
              $word_y = $rowsWords [ 1 ];
              if ( $word_x [ 'word' ] == $word ) {
                $word_x = $word_y;
              }
              if ( $charge == 1 ) {
                $this->addSynonymousCallNames ( $word_x [ 'word' ], $word_y [ 'word' ] );
              }
            }
          }
        }
      }
    }
    
    public function linkWords ( $word_x, $word_y, $rate ) {
      $rows = $this->parent->database->sql ( "SELECT `id`, `rate` FROM `words` WHERE `word` = '" . $word_x . "' OR `word` = '" . $word_y . "'" );
      if ( sizeof ( $rows ) < 2 ) {
        $this->parent->database->insert ( 'words', array ( 'word' ), array ( 'word' => $word_y ) );
        $rows = $this->parent->database->sql ( "SELECT `id`, `rate` FROM `words` WHERE `word` = '" . $word_x . "' OR `word` = '" . $word_y . "'" );
      }
      if ( sizeof ( $rows ) == 2 ) {
        $id_x = $rows [ 0 ] [ 'id' ];
        $id_y = $rows [ 1 ] [ 'id' ];
        $rows = $this->parent->database->sql ( "SELECT `id`, `rate` FROM `links` WHERE `word_x` = '" . $id_x . "' AND `word_y` = '" . $id_y . "'" );
        if ( sizeof ( $rows ) == 0 ) {
          $this->parent->database->insert ( 'links', array ( 'word_x', 'word_y', 'rate' ), array ( 'word_x' => $id_x, 'word_y' => $id_y, 'rate' => $rate ) );
        } elseif ( sizeof ( $rows ) == 1 ) {
          $rate = ( ( $rows [ 0 ] [ 'rate' ] + $rate ) / 2 );
          $this->parent->database->sql ( "UPDATE links SET rate = " . $rate . " WHERE word_x = " . $id_x . " AND word_y = " . $id_y );
        }
      }
    }
    
    public function addSynonymousCallNames ( $call_name, $synonymous_name ) {
      if ( isset ( $this->synonyms [ $call_name ] ) ) {
        if ( !in_array ( $synonymous_name, $this->synonyms [ $call_name ] ) ) {
          $this->synonyms [ $call_name ] [ ] = $synonymous_name;
        }
      } else {
        $this->synonyms [ $call_name ] = [ $synonymous_name = 1 ];
      }
      if ( isset ( $this->synonyms [ $synonymous_name ] ) ) {
        if ( !in_array ( $call_name, $this->synonyms [ $synonymous_name ] ) ) {
          $this->synonyms [ $synonymous_name ] [ ] = $call_name;
        }
      } else {
        $this->synonyms [ $synonymous_name ] = [ $call_name = 1 ];
      }
    }
    
    public function getSynonymousCallNames ( $call_name ) {
      $synonyms = [ $call_name ];
      if ( isset ( $this->synonyms [ $call_name ] ) ) {
        foreach ( $this->synonyms [ $call_name ] as $key => $value ) {
          if ( !in_array ( $value, $synonyms ) ) {
            $synonyms [ ] = $value ;
            $add_as = false;
            $adjacent_synonyms = [ ];
            foreach ( $this->synonyms [ $value ] as $key_as => $value_as ) {
              if ( !in_array ( $value_as, $adjacent_synonyms ) && !in_array ( $value_as, $synonyms ) ) {
                $adjacent_synonyms [ ] = $value_as;
              } else if ( $value_as == $call_name ) {
                $add_as = true;
              }
            }
            if ( $add_as ) {
              array_merge ( $synonyms, $adjacent_synonyms );
            }
          }
        }
      } else {
        $this->synonyms [ $call_name ] = [ ];
      }
      return $synonyms;
    }
  }
?>