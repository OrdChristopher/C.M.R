<?php
  class data extends \PDO {
    public $key = null;
    public $key_value = null;
    private $database = null;
    private $update = false;
    private $insert = false;
    private $select = false;
    private $values = [ ];
    private $table = null;
    public $rows = null;
    public $queries = 0;
    
    public static function exception_handler ( $exception ) {
      die ( 'Uncaught exception: '. $exception->getMessage ( ) );
    }
    
    public function __construct ( $database, $table, $key_value = null, $row = null, $and = true ) {
      ini_set ( 'max_execution_time', 0 );
      ini_set ( 'memory_limit', '512m' );
      $this->database = $database;
      $this->table = $table;
      set_exception_handler ( [ __CLASS__, 'exception_handler' ] );
      parent::__construct ( "mysql:host=localhost;dbname={$this->database}", 'root', '', [ \PDO::MYSQL_ATTR_FOUND_ROWS => true ] );
      restore_exception_handler ( );
      $this->key = $this->getKey ( );
      if ( is_array ( $row ) || is_int ( $key_value ) ) {
        if ( is_array ( $row ) ) {
          foreach ( $row as $key => $value ) {
            $this->select = true;
            if ( !is_numeric ( $key ) && !empty ( $value ) ) {
              $this->values [ $key ] = [ 'value' => $value, 'data' => false ];
            }
          }
        }
        if ( is_numeric ( $key_value ) ) {
          $this->key_value = $key_value;
          if ( isset ( $this->values [ $this->key ] [ 'value' ] ) ) {
            $key_value = intval ( $this->values [ $this->key ] [ 'value' ] );
            if ( $key_value == $this->key_value ) {
              $this->select = false;
            }
          }
        }
        $this->load ( $and );
      }
    }
    
    public function __get ( $key ) {
      if ( isset ( $this->values [ $key ] ) ) {
        return $this->values [ $key ] [ 'value' ];
      }
      return null;
    }
    
    public function row ( $index ) {
      if ( is_int ( $index ) && isset ( $this->values [ $index ] ) ) {
        return $this->values [ $index ];
      }
      return [ ];
    }
    
    public function __set ( $key, $value ) {
      if ( isset ( $this->values [ $key ] ) ) {
        if ( $value == $this->values [ $key ] [ 'value' ] ) {
          return $value;
        }
      }
      if ( $this->select ) {
        $this->update = true;
      } else {
        $this->insert = true;
      }
      return $this->values [ $key ] = [ 'value' => $value, 'data' => true ];
    }
    
    public function __destruct ( ) {
      if ( $this->update || $this->insert ) {
        $this->save ( );
      }
    }
    
    public function getCommaSeperatedPlaceholders ( $keyed = true, $array = [ ], $and = false ) {
      $string = "";
      if ( is_array ( $array ) ) {
        foreach ( $array as $key => $value ) {
          if ( $keyed ) {
            $string .= "{$key} = ";
          }
          if ( $and ) {
            if ( $and == 'or' ) {
              $string .= ":{$key} OR ";
            } else {
              $string .= ":{$key} AND ";
            }
          } else {
            $string .= ":{$key},";
          }
        }
        $string = rtrim ( rtrim ( rtrim ( $string, ' OR ' ), ' AND ' ), ',' );
      }
      return $string;
    }
    
    public function getSelectSQL ( $data, $select = '*', $and = true ) {
      $data_new = [ ];
      $comma_seperated_select_placeholders = "";
      foreach ( $data as $key => $value ) {
        if ( is_array ( $value ) ) {
          foreach ( $value as $key_new => $value_new ) {
            $data_new [ "{$key}_{$key_new}" ] = $value_new;
            $comma_seperated_select_placeholders .= "{$key} = '{$value_new}' OR ";
          }
          $comma_seperated_select_placeholders = rtrim ( $comma_seperated_select_placeholders, ' OR ' ) . ( strpos ( $comma_seperated_select_placeholders, "AND" ) > -1 ? ")" : "" );
        } else {
          if ( strpos ( $value, 'LIKE' ) ) {
            $comma_seperated_select_placeholders = "{$key} {$value} AND (";
          } else {
            //$comma_seperated_select_placeholders = "{$key} = {$value}, AND";
          }
        }
      }
      if ( empty ( $comma_seperated_select_placeholders ) ) {
        $comma_seperated_select_placeholders = $this->getCommaSeperatedPlaceholders ( true, $data, $and );
      }
      if ( is_array ( $select ) ) {
        $selection = "(";
        foreach ( $select as $key => $value ) {
          $selection .= "{$value},";
        }
        $select = rtrim ( $selection, ',' ) . ")";
      }
      //print_r ( [ 'sql' => "SELECT * FROM {$this->table}" . ( empty ( $comma_seperated_select_placeholders ) ? '' : " WHERE {$comma_seperated_select_placeholders}" ) . ";", 'data' => empty ( $data_new ) ? $data : $data_new ] );
      return [ 'sql' => "SELECT {$select} FROM {$this->table}" . ( empty ( $comma_seperated_select_placeholders ) ? '' : " WHERE {$comma_seperated_select_placeholders}" ) . ";", 'data' => empty ( $data_new ) ? $data : $data_new ];
    }
    
    public function getUpdateSQL ( $data ) {
      $comma_seperated_update_placeholders = $this->getCommaSeperatedPlaceholders ( true, $data );
      return "UPDATE {$this->table} SET {$comma_seperated_update_placeholders} WHERE key_value = :key_value;";
    }
    
    public function getInsertSQL ( $data ) {
      $comma_seperated_insert_placeholders = $this->getCommaSeperatedPlaceholders ( false, $data );
      $comma_seperated_insert_names = str_replace ( ':', '', $comma_seperated_insert_placeholders );
      return "INSERT INTO {$this->table} ({$comma_seperated_insert_names}) VALUES ({$comma_seperated_insert_placeholders});";
    }
    
    public function getDataAppendIdentifier ( $array = [ ] ) {
      if ( is_array ( $array ) ) {
        $array = array_merge ( $array, [ $this->key => $this->key_value ] );
      }
      return $array;
    }
    
    public function setDataState ( $data, $state ) {
      foreach ( $data as $key => $value ) {
        $this->values [ $key ] [ 'data' ] = $state;
      }
    }
    
    public function prepareExecute ( $sql, $data = null ) {
      $statement = $this->prepare ( $sql );
      $statement->execute ( $data );
      $this->queries++;
      return $statement;
    }
    
    public function dataStateTransition ( $sql, $data, $select = false ) {
      $statement = $this->prepareExecute ( $sql, $data );
      if ( $statement->rowCount ( ) > 0 || $select ) {
        if ( $select ) {
          return $statement->fetchAll ( \PDO::FETCH_ASSOC );
        }
        $this->setDataState ( $data, false );
        return true;
      }
      return false;
    }
    
    public function getDataValues ( $state = true ) {
      $data = [ ];
      foreach ( $this->values as $key => $value ) {
        if ( $value [ 'data' ] == $state ) {
          $data [ $key ] = $value [ 'value' ];
        }
      }
      return $data;
    }
    
    public function getKey ( ) {
      $statement = $this->prepareExecute ( "DESCRIBE {$this->table};" );
      $rows = $statement->fetchAll ( \PDO::FETCH_ASSOC );
      if ( sizeof ( $rows ) > 0 ) {
        foreach ( $rows as $key => $value ) {
          foreach ( $value as $column_key => $column_value ) {
            if ( strtoupper ( $column_key ) == 'KEY' ) {
              return $rows [ $key ] [ 'Field' ];
            }
          }
        }
      }
    }
    
    public function getColumns ( ) {
      $columns = [ ];
      $statement = $this->prepareExecute ( "DESCRIBE {$this->table};" );
      $rows = $statement->fetchAll ( \PDO::FETCH_ASSOC );
      if ( sizeof ( $rows ) > 0 ) {
        foreach ( $rows as $key => $value ) {
          foreach ( $value as $column_key => $column_value ) {
            if ( strtoupper ( $column_key ) == 'KEY' ) {
              $columns [ ] = $rows [ $key ] [ 'Field' ];
            }
          }
        }
      }
      return $columns;
    }
    
    public function load ( $and = true ) {
      if ( $this->select ) {
        if ( is_null ( $this->key_value ) ) {
          $data = $this->getDataValues ( false );
          $sql = $this->getSelectSQL ( $data, '*', $and );
          $rows = $this->dataStateTransition ( $sql [ 'sql' ], $sql [ 'data' ], true );
        }
      } else {
        $this->values = [ $this->key => [ 'value' => $this->key_value, 'data' => false ] ];
        $data = $this->getDataValues ( false );
        $sql = $this->getSelectSQL ( $data, '*', $and );
        $rows = $this->dataStateTransition ( $sql, $data, true );
      }
      //print_r ( $sql );
      $this->rows = sizeof ( $rows );
      if ( $this->rows  == 1 ) {
        $this->select = true;
        $this->insert = false;
        $this->update = false;
        foreach ( $rows as $key => $value ) {
          if ( $key == $this->key ) {
            $this->key_value = intval ( $value );
          }
          $this->values [ $key ] = [ 'value' => $value, 'data' => false ];
        }
        return true;
      } else if ( $this->rows  > 1 ) {
        $this->select = true;
        $this->insert = false;
        $this->update = false;
        $this->rows = $this->rows ;
        for ( $index = 0; $index < $this->rows ; $index++ ) {
          $row = $rows [ $index ];
          foreach ( $row as $key => $value ) {
            if ( $key == $this->key ) {
              $this->key_value = intval ( $value );
            }
            $this->values [ $index ] [ $key ] = [ 'value' => $value, 'data' => false ];
          }
        }
        return true;
      } else {
        $this->values = [ ];
      }
      return false;
    }
    
    public function save ( ) {
      if ( $this->update || $this->insert ) {
        $data = $this->getDataValues ( true );
        if ( sizeof ( $data ) > 0 ) {
          if ( $this->update ) {
            $sql = $this->getUpdateSQL ( $data );
            $data = $this->getDataAppendIdentifier ( $data );
          } else if ( $this->insert ) {
            $sql = $this->getInsertSQL ( $data );
          }
          if ( $this->dataStateTransition ( $sql, $data ) ) {
            $this->key_value = $this->lastInsertId ( );
            $this->update = $this->insert = false;
          }
        }
      }
    }
  }