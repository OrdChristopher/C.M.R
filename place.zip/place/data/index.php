<?php
  require_once "data.php";
  require_once "language.php";
  require_once "synonymous_calls.php";
  
  $language = new language ( 'latin' );
  $synonymous_calls = new synonymous_calls ( );
  if ( isset ( $_REQUEST [ 'textarea' ] ) ) {
    $output = [];
    $data = $language->getSpaceLanguageClusters ( urldecode ( $_REQUEST [ 'textarea' ] ) , 'latin' );
    //link all words as a phrase
    // word id
    // phrase id
    // word id, phrase id
    $words = [ ];
    foreach ( $data as $key => $value ) {
      // see if word exists? add word
      $word = new data ( 'place', 'word', null, [ 'word' => $value ] );
      if ( $word->rows <= 0 ) {
        $word = new data ( 'place', 'word', null );
        $word->word = $value;
        $word->save ( );
        $words [ ] = intval ( $word->key_value [ 0 ] );
      } elseif ( $word->rows >= 1 ) {
        $words [ ] = intval ( $word->row ( 0 ) [ 'value' ] [ $word->key ] );
      } else {
        $words [ ] = intval ( $word );
      }
      $parameters = array_merge ( array_slice ( $data, ( $key != 0 ? 0 : 1 ), ( $key - 1 < 0 ? 0 : $key ) ), array_slice ( $data, $key + 1, sizeof ( $data ) - $key - 1 ) );
      //print_r ( $parameters );
      if ( $result = $synonymous_calls->$value ( $parameters ) !== false ) {
        $output [ ] [ $value ] =  [ $parameters, $synonymous_calls->$value ( $parameters ) ];  //check for calls, testing mode
      }
    }
    // see if phrase exists? add phrase
    $json_phrase = strval ( json_encode ( $words ) );
    $phrase = new data ( 'place', 'phrase', null, [ 'json_phrase' => $json_phrase ] );
    if ( $phrase->rows <= 0 ) {
      $phrase = new data ( 'place', 'phrase', null );
      $phrase->json_phrase = $json_phrase;
      $phrase->save ( );
      $phrase = intval ( $phrase->key_value [ 0 ] );
    } elseif ( $word->rows == 1 ) {
      $phrase = intval ( $phrase->row ( 0 ) [ 'value' ] [ $phrase->key ] );
    } else {
      $phrase = json_decode ( $json_phrase ) [ 0 ];
    }
    // percentage link from word to word in phrase? increase from average place in phrase.
    foreach ( $words as $key => $value ) {// see if word exists? add word
      if ( is_numeric ( $value ) ) {
        $word_phrase = new data ( 'place', 'word_phrase', null, [ 'word' => $value, 'phrase' => $phrase ] );
        if ( $word_phrase->rows <= 0 ) {
          $word_phrase = new data ( 'place', 'word_phrase', null );
          $word_phrase->word = $value;
          if ( is_numeric ( $phrase ) && $phrase !== false ) {
            $word_phrase->phrase = $phrase;
            $word_phrase->mean = ( 1 / sizeof ( $words ) );
            $word_phrase->save ( );
          }
        }
      }
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, expand-on-scroll=no, vh-unit=min, containing-block=min" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    
    <title>#temahtw index.php</title>
    
    <style type="text/css">
      * {
        
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }
      
      form {
        width: 75vw;
        height: 100%;
        margin: 0 auto;
      }
      
      header::after, content::after, footer::after {
        clear: both;
        display: table;
        width: 100%;
      }
      
      header {
        height: 25%;
        min-height: 25vh;
        width: 25%;
        display: table;
        text-align: center;
        margin: 0 auto;
      }
      
      header a {
        display: table-cell;
        vertical-align: middle;
        text-decoration: none;
      }
      
      content {
        display: flex;
        width: 100%;
      }
      
      content textarea {
        width: 100%;
        min-width: 100%;
        height: 50vh;
        min-height: 30vh;
        max-height: 50vh;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
      }
      
      footer {
        clear: both;
        height: 25vh;
        width: 100%;
      }
      
      footer button {
        float: right;
        width: 50%;
        height: 100%;
        background: transparent;
        border: none;
        outline: none;
      }
      
      footer button:first-child {
        float: left;
      }
      
      @media screen and (orientation: landscape) {
        * {
          transform: translateX(0);
          transform: translateY(0);
        }
      }
      
      header a, footer button, content textarea {
        font-weight: bold;
        text-shadow: 1px 1px 1px #999;
      }
      
      header a:hover, footer button:hover {
        color: #999;
        text-shadow: 1px 1px 2px #ccc;
      }
    </style>
  </head>
  <body>
    <form>
      <header>
        <a href="#">&#63;</a>
      </header>
      <content>
<?php
  if ( !isset ( $data ) ) {
?>
        <textarea autofocus name="textarea" placeholder="&#8220;Keep on asking, and it will be given you; keep on seeking, and you will find; keep on knocking, and it will be opened to you; for everyone asking receives, and everyone seeking finds, and to everyone knocking, it will be opened.&#8221; (New World Translation, Matthew. 7.7-8)"></textarea>
<?php
  } else {
    echo '<pre>', var_dump ( $data ), var_dump ( $output ), '</pre>';
  }
?>
      </content>
      <footer>
        <button>&#10006;</button>
        <button>&#10004;</button>
      </footer>
    </form>
  </body>
</html>