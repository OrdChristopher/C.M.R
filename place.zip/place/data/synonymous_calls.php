<?php
  require_once ( 'data.php' );
  
  class synonymous_calls {
    private $data = null;
    
    public function __construct ( ) {
      //$this->data = new data ( 'place', 'unicode_data', null );
    }
    
    public function __call ( $method, $arguments ) {
      $synonymous_calls = $this->getSynonymousCallNames ( $method );
      $reflexive_synonymous_calls = [ ];
      foreach ( $synonymous_calls as $key => $value ) {
        if ( method_exists ( $this, $value ) ) {
          $reflectionMethod = new \ReflectionMethod ( 
            $this,
            $value
          );
          if ( sizeof ( $arguments ) >= $reflectionMethod->getNumberOfRequiredParameters ( ) ) {
            $reflexive_synonymous_calls [ ] = $value;
          }
        }
      }
      foreach ( $reflexive_synonymous_calls as $key => $value ) {
        try {
          
          return $this->$value ( $arguments [ 0 ] );
          
        } catch ( Exception $ex ) {
          
          return false;
          
        }
      }
      return false;
    }
    
    public function getSynonymousCallNames ( $method ) {
      $synonyms = [ ];
      $synonym_keys = [ ];
      $word = new data ( 'place', 'word', null, [ 'word' => $method ] );
      if ( $word->rows >= 1 ) {
        $key_value = $word->row ( 0 ) [ 'value' ] [ 'identifier' ];
        $word_chain = new data ( 'place', 'word_chain', null, [ 'word_x' => $key_value, 'word_y' => $key_value ], 'or' );
        if ( $word_chain->rows >= 1 ) {
          for ( $index = 0; $index < $word_chain->rows; $index++ ) {
            $word_x = $word_chain->row ( $index ) [ 'value' ] [ 'word_x' ];
            $word_y = $word_chain->row ( $index ) [ 'value' ] [ 'word_y' ];
            $synonym_key = $word_x;
            if ( $key_value == $word_x ) {
              $synonym_key = $word_y;
            }
            if ( !in_array ( $synonym_key, $synonym_keys ) ) {
              $synonym_keys [ ] = $synonym_key;
              $synonym_word = new data ( 'place', 'word', null, [ 'identifier' => $synonym_key ] );
              if ( $synonym_word->rows >= 1 ) {
                $synonyms [ ] = $synonym_word->row ( 0 ) [ 'value' ] [ 'word' ];
              }
            }
          }
        } else {
          //echo $method . "no chain";
        }
      }
      return $synonyms;
    }
    
    public function add ( ...$parameters ) {
      $numbers = [];
      foreach ( $parameters [ 0 ] as $key => $value ) {
        if ( is_numeric ( $value ) ) {
          $numbers [ ] = intval ( $value );
        }
      }
      return array_sum ( $numbers );
    }
  }