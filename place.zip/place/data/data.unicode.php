<?php
	require_once ( 'data.pdo.php' );
	class unicode extends data {
		
	}
?>