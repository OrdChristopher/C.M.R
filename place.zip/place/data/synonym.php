<?php
  require_once ( 'data.php' );
  
  class synonymous_calls {
    private $data = null;
    
    public function __construct ( ) {
      //$this->data = new data ( 'place', 'unicode_data', null );
    }
    
    public function __call ( $method, $arguments ) {
      $synonymous_calls = $this->getSynonymousCallNames ( $method );
      $reflexive_synonymous_calls = [ ];
      foreach ( $synonymous_calls as $key => $value ) {
        if ( method_exists ( $this, $value ) ) {
          $reflectionMethod = new \ReflectionMethod ( 
            $this,
            $value
          );
          if ( sizeof ( $arguments ) == $reflectionMethod->getNumberOfRequiredParameters ( ) ) {
            $reflexive_synonymous_calls [ ] = $value;
          }
        }
      }
      foreach ( $reflexive_synonymous_calls as $key => $value ) {
        try {
          
          return $this->$value ( $arguments );
          
        } catch ( Exception $ex ) {
          
          return false;
          
        }
      }
      return false;
    }
  }