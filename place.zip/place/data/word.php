<?php
  require_once ( 'data.php' );
  
  class word {
    private $data = null;
    
    public function addWord (  ) {
      
    }
  }
?>