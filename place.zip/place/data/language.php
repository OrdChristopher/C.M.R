<?php
  require_once ( 'data.php' );
  
  class language {
    private $data = null;
    public $character_cluster = [ ];
    
    public function __construct ( $language = null ) {
      $this->data = new data ( 'place', 'unicode_data', null, [ 'canonical_combining_classes' => [ 'Zs', 'Zl', 'Zp' ] ] );
      if ( $this->data->rows > 0 ) {
        $this->character_cluster [ 'space' ] = [ ];
        for ( $index = 0, $rows = $this->data->rows; $index < $rows; $index++ ) {
          $row = $this->data->row ( $index );
          $this->character_cluster [ 'space' ] [ ] = mb_chr ( hexdec ( "{$row [ 'code_value' ] [ 'value' ]}" ) );
        }
      }
      $language = strtoupper ( is_null ( $language ) ? $this->getLanguageOrDefault ( $language ) : $language );
      $this->data = new data ( 'place', 'unicode_data', null, [ 'character_name' => "LIKE '%{$language}%LETTER%'", 'canonical_combining_classes' => [ 'Lt', 'Ll', 'Lu', 'Cf', 'Lo' ] ] );
      if ( $this->data->rows > 0 ) {
        $this->character_cluster [ $language ] = [ ];
        for ( $index = 0, $rows = $this->data->rows; $index < $rows; $index++ ) {
          $row = $this->data->row ( $index );
          $this->character_cluster [ $language ] [ ] = mb_chr ( hexdec ( "{$row [ 'code_value' ] [ 'value' ]}" ) );
        }
      }
    }
    
    public function getLanguageOrDefault ( $language = null ) {
      if ( isset ( $this->character_cluster [ $language ] ) ) {
        return $language;
      }
      return $this->default_language;
    }
    
    public function getLanguageCluster ( $value, $language ) {
      $string = "";
      $value = $this->getCharacterCluster ( $value );
      $language = $this->character_cluster [ strtoupper ( $language ) ];
      $space = $this->getCharacterCluster (  $this->character_cluster [ "space" ] );
      $language_space = array_merge ( $language, $space );
      for ( $size = count ( $value ), $index = 0; $index < $size; $index++ ) {
        $character = $value [ $index ];
        if ( in_array ( $character, $language_space ) || is_numeric ( $character ) ) {
          $string .= $character;
        }
      }
      return $string;
    }
    
    public function getSpaceLanguageClusters ( $value, $language ) {
      $array = [ ];
      $array_position = 0;
      $space_clusters = $this->getSpaceClusters ( $value );
      $language = $this->character_cluster [ strtoupper ( $language ) ];
      for ( $size = count ( $space_clusters ), $index = 0; $index < $size; $index++ ) {
        $space_cluster = $this->getCharacterCluster ( $space_clusters [ $index ] );
        for ( $size_space_cluster = count ( $space_cluster ), $index_space_cluster = 0; $index_space_cluster < $size_space_cluster; $index_space_cluster++ ) {
          $character = $space_cluster [ $index_space_cluster ];
          if ( ( is_array ( $language ) && in_array ( $character, $language ) ) || is_numeric ( $character ) ) {
            if ( isset ( $array [ $index ] ) ) {
              $array [ $index ] .= $character;
            } else {
              $array [ $index ] = $character;
            }
          }
        }
      }
      return $array;
    }
    
    public function getSpaceClusters ( $value ) {
      $array = [ ];
      $array_position = 0;
      $value = $this->getCharacterCluster ( $value );
      $space = $this->getCharacterCluster (  $this->character_cluster [ "space" ] );
      for ( $size = count ( $value ), $index = 0; $index < $size; $index++ ) {
        $character = $value [ $index ];
        if ( in_array ( $character, $space ) || ctype_space ( $character ) || ( $character == "\n" || $character == "\r" || $character == "\r\n" ) ) {
          $array [ ] = "";
          $array_position = sizeof ( $array ) - 1;
        } else {
          if ( isset ( $array [ $array_position ] ) ) {
            $array [ $array_position ] .= $character;
          } else {
            $array [ $array_position ] = $character;
          }
        }
      }
      return $array;
    }
    
    public function getCharacterCluster ( $value ) {
      $array = [ ];
      if ( is_array ( $value ) ) {
        $array = $value;
      } else {
        $value = strval ( $value );
        for ( $size = strlen ( $value ), $index = 0; $index < $size; $index++ ) {
          $character = $value [ $index ];
          $array [ ] = $character;
        }
      }
      return $array;
    }
  }

  
  