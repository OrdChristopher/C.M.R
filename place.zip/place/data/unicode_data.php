<?php
  require_once ( 'data.php' );
  
  class unicode_data {
    public $data = null;
    private $map = null;
    
    public function __construct ( ) {
      ini_set ( 'max_execution_time', 0 );
      $this->data = new data ( 'place', 'unicode_data', null );
      $this->map = array_values ( $this->data->getColumns ( ) );
    }
    
    public function parseUnicodeData ( ) {
      $url = "UnicodeData.txt";
      $contents = explode ( "\r", file_get_contents ( $url ) );
      echo sizeof ( $contents );
      foreach ( $contents as $key => $value ) {
        $values = array_values ( array_merge ( [ null ], explode ( ';', $value ) ) );
        for ( $size = sizeof ( $this->map ), $index = 0; $index < $size; $index++ ) {
          $this->data->{$this->map [ $index ]} = strval ( $values [ $index ] );
        }
        $this->data->save ( );
        $this->data = new data ( 'place', 'unicode_data', null );
      }
    }
  }
  
  $unicode_data = new unicode_data ( );
  $unicode_data->data = new data ( 'place', 'unicode_data', null, [ 'canonical_combining_classes' => [ 'Zs', 'Zl', 'Zp' ] ] );
  var_Dump ( $unicode_data) ;
  
  print_r ( $unicode_data->data->row ( 0 ) );
  //query latin letters; SELECT * FROM unicode_data WHERE character_name LIKE '%LATIN%LETTER%'AND (canonical_combining_classes = 'Lt' OR canonical_combining_classes = 'Ll' OR canonical_combining_classes = 'Lu');
  //query white space; SELECT * FROM unicode_data WHERE canonical_combining_classes = 'Zs' OR canonical_combining_classes = 'Zl' OR canonical_combining_classes = 'Zp';