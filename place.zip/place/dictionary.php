<?php
  require_once ( 'database.php' );

  class dictionary {
    
    private $database = null;
    private $dictionary = null;
    
    public function __construct ( $jsonFilePath = "words_dictionary.json" ) {
      
      $this->database = new database;
      $this->dictionary = json_decode ( file_get_contents ( $jsonFilePath ), true );
      
    }
    
    public function hasWord ( $word ) {
      
      if ( sizeof ( $rows = $this->database->select ( 'words', array ( 'id', 'rate' ), array ( 'word' ), array ( 'word' => $word ) ) ) > 0 ) {
        
        return true;
        
      }
      
      return false;
      
    }
    
    public function rootWords ( $word ) {
    
      $rootWords = array ( );
      $wordLength = strlen ( $word );
      
      if ( $wordLength > 1 ) {
        
        $possibleRoot = array ( );
        
        for ( $index = 0, $size = $wordLength - 1; $index < $size; $index++ ) {
          
          $rootWord = substr ( $word, $index, $size - $index );
          
          if ( !in_array ( $rootWord, $possibleRoot ) ) {
            
            $possibleRoot [ ] = $rootWord;
          
          }
          
        }
        
        for ( $index = $wordLength - 1; $index > 0; $index-- ) {
          
          $rootWord = substr ( $word, 0, $index );
          
          if ( !in_array ( $rootWord, $possibleRoot ) ) {
            
            $possibleRoot [ ] = $rootWord;
          
          }
          
        }
        
        for ( $index = 1, $size = $wordLength; $index < $size; $index++ ) {
          
          $rootWord = substr ( $word, $index, $size - $index  );
          
          if ( !in_array ( $rootWord, $possibleRoot ) ) {
            
            $possibleRoot [ ] = $rootWord;
          
          }
          
        }
        
        for ( $index = $wordLength; $index > 1; $index-- ) {
          
          $rootWord = substr ( $word, 1, $index  );
          
          if ( !in_array ( $rootWord, $possibleRoot ) ) {
            
            $possibleRoot [ ] = $rootWord;
          
          }
          
        }
        
        foreach ( $possibleRoot as $key => $value ) {
          
          if ( $this->hasWord ( $value ) ) {
            
            if ( strlen ( $value ) > 1 && !in_array ( $value, $rootWords ) ) {
              
              $rootWords [ ] = $value;
            
            }
            
          } else {
            
            $rootWords = array_unique ( array_merge ( $rootWords, $this->rootWords ( $rootWord ) ) );
            
          }
         
        }
        
      }
      
      usort ( $rootWords, function ( $a, $b ) {
        
        return strlen ( $a ) - strlen ( $b ) ?: strcmp ( $a, $b );
        
      } );
      
      return $rootWords;
    
    }
    
  }