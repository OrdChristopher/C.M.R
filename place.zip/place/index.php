<?php
  ini_set('memory_limit', '1280M');
  ini_set('upload_max_filesize', '128M');
  ini_set('post_max_size', '128M');
  ini_set('file_uploads', 'On');
  ini_set('max_execution_time', '300');
  ini_set('file_uploads', 'On');
  
  require ( 'html5.php' );
  require ( 'synonym.php' );
  require ( 'pattern.php' );
  require ( 'safepdo.php' );
  require ( 'database.php' );
  require ( 'dictionary.php' );
  
  class index {
    public $synonym = null;
    public $pattern = null;
    public $database = null;
    public $dictionary = null;
    private $html5 = null;
    private $html = null;
    
    public function __construct ( ) {
      $this->synonym = new synonym ( $this );
      $this->pattern = new pattern ( );
      $this->database = new database ( );
      $this->dictionary = new dictionary ( );
      $this->html5 = new html5 ( );
      $this->index ( );
      $this->html5->setTags ( $this->html );
    }
    
    public function index ( ) {
      switch ( $_SERVER [ 'REQUEST_METHOD' ] ) {
        case 'GET':
        case 'POST':
          $keys = array_keys ( $_REQUEST );
          $values = array_values ( $_REQUEST );
          foreach ( $_REQUEST as $key => $value ) {
            if ( method_exists ( $this, $key ) ) {
              $arguments = [ ];
              if ( isset ( $_REQUEST [ $key ] ) ) {
                $arguments [ $key ] = $_REQUEST [ $key ];
              }
              $json_value = json_decode ( $value );
              if ( is_array ( $json_value ) ) {
                foreach ( $json_value as $key => $value ) {
                  if ( isset ( $_REQUEST [ $value ] ) ) {
                    $arguments [ $key ] = $_REQUEST [ $value ];
                  }
                }
              } else if ( isset ( $_REQUEST [ $value ] ) ) {
                $arguments [ $value ] = $_REQUEST [ $value ];
              }
              $this->$key ( $arguments );
            }
          }
          break;
        default:
          echo 'UNHANDLED REQUEST METHOD';
          break;
      }
      $this->setHtml ( '{"html":{"head":{"title":["index.php"]},"body":{"form":{"0":{"name":"method","value":"post"},"1":{"name":"align","value":"center"},"textarea":[{"name":"name","value":"textarea"},{"name":"placeholder","value":"textarea"},{"name":"value","value":""},""],"input":[{"name":"type","value":"submit"},{"name":"name","value":"submit"},{"name":"value","value":"textarea"}],"br":[],"a":[{"name":"href","value":"d.php"},{"name":"text-align","value":"center"},"Dictionary"]}}}}' );
    }
    
    public function __call ( $method, $arguments ) {
      $synonymous_calls = $this->synonym->getSynonymousCallNames ( $method );
      $reflexive_synonymous_calls = [ ];
      foreach ( $synonymous_calls as $key => $value ) {
        if ( method_exists ( $this, $value ) ) {
          $reflectionMethod = new \ReflectionMethod ( 
            $this,
            $value
          );
          if ( sizeof ( $arguments ) == $reflectionMethod->getNumberOfRequiredParameters ( ) ) {
            $reflexive_synonymous_calls [ ] = $value;
          }
        }
      }
      foreach ( $reflexive_synonymous_calls as $key => $value ) {
        try {
          
          return $this->$value ( $arguments );
          
        } catch ( Exception $ex ) {
          
          
        }
      }
    }
    
    public function submit ( $arguments = [ ] ) {
      $call_name = null;
      $typed_name = [ ];
      $data = [ ];
      foreach ( $arguments as $key => $value ) {
        if ( isset ( $arguments [ $value ] ) && isset ( $arguments [ $key ] ) ) {
          $call_name = $key;
          $typed_name = json_decode ( $value );
          if ( !is_array ( $typed_name ) ) {
            $typed_name [ $value ] = $arguments [ $value ];
          }
        } else if ( !isset ( $typed_name [ $key ] ) ) {
          $data [ $key ] = $value;
        }
      }
      switch ( $call_name ) {
        case "submit":
          foreach ( $typed_name as $name => $value ) {
            if ( method_exists ( $this, $name ) ) {
              $typed_name [ $name ] = $this->$name ( $value );
            }
          }
          $values = implode ( " ", array_values ( array_merge ( $typed_name, $data ) ) );
          
          $patternOfSymbols = $this->pattern->patternOfSymbols ( $values );
          $patternOfGroups = $patternOfSymbols [ 'groups' ];
          $wordIdsOfGroups = [ ];
          print_R ( $patternOfSymbols );
          foreach ( $patternOfGroups as $key => $value ) {
            if ( !empty ( $key ) ) {
              $rows = $this->database->sql ( "SELECT `id`, `rate` FROM `words` WHERE `word` = '{$key}'" );
              if ( sizeof ( $rows ) == 0 ) {
                $wordIdsOfGroups [ $key ] = $this->database->insert ( 'words', [ 'word' ], [ 'word' => $key ] );
              } else {
                $wordIdsOfGroups [ $key ] = $rows [ 0 ] [ 'id' ];
              }
            }
          }
          //groups shall link upon rate of occurance.
          $rateOfOccurance = 1 / sizeof ( $patternOfGroups );
          foreach ( $wordIdsOfGroups as $key => $value ) {
            foreach ( $wordIdsOfGroups as $key_recurse => $value_recurse ) {
              if ( $key != $key_recurse ) {
                $this->synonym->linkWords ( $key, $key_recurse, $rateOfOccurance );
              }
            }
          }
          break;
        default:
          echo 'UNHANDLED SUBMIT METHOD';
          break;
      }
    }
    
    public function textarea ( $data ) {
      return filter_var ( $data, FILTER_SANITIZE_STRING ); //FILTER_SANITIZE_FULL_SPECIAL_CHARS for html output
    }
    
    public function x ( $arguments = [ ] ) {
      //echo "x";
    }
    
    public function setHtml ( $json ) {
      $this->html = json_decode ( $json, true );
    }
    
    public function getHtml ( ) {
      return $this->html;
    }
    
    public function getJson ( ) {
      return json_encode ( $this->html );
    }
    
  }
  
  $index = new index ( );
?>