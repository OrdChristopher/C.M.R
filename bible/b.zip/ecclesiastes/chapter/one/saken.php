<?php
	class saken {
		private $rasen;
		
		public function __construct ( ) {
			
		}
	}
?>