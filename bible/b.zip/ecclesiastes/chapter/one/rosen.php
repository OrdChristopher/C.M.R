<?php
	class rosen {
		private $soken;
		
		public function __construct ( ) {
			
		}
	}
?>